import {Wave } from './point.js';

export class WaveGroup {
    constructor() {
        this.totalWaves=3;
        this.totalPoints=6;
        this.color=['rgba(248,176,58,0.5)','rgba(255,221,124,0.5)','rgba(246,244,244,0.5)'];
        this.waves=[];

        for(let i=0; i<this.totalWaves;i++) {
            const wave=new Wave (
                i,this.totalPoints,this.color[i]
            );
            this.waves[i]=wave;
        }
    }

    resize(stageWidth, stageHeight) {
        for(let i=0; i<this.totalWaves;i++){
            const wave=this.waves[i];
            wave.resize(stageWidth,stageHeight);
        }
    }
    
    draw(ctx) {
        for(let i=0; i<this.totalWaves;i++){
            const wave=this.waves[i];
            wave.draw(ctx);
        }
    }
}