// const { Wave } = require("./point");
import { WaveGroup } from "./WaveGroup.js";

class App {
    constructor(){  
        this.canvas=document.getElementById('wave');
        // this.canvas=document.createElement('canvas');
        // document.body.appendChild(this.canvas);
        this.ctx=this.canvas.getContext('2d');

        this.WaveGroup=new WaveGroup();
    
        window.addEventListener('resize',this.resize.bind(this),false);
        this.resize();

        window.requestAnimationFrame(this.animate.bind(this));
    
    }

    resize(){
        this.stageWidth = document.body.clientWidth;
        this.stageHeight=document.body.clientHeight;

        // alert("사이즈 : ("+document.body.clientWidth+","+document.body.clientHeight+")");
        this.canvas.width=this.stageWidth *2;
        this.canvas.height=this.stageHeight * 2;
        this.ctx.scale(2, 2); //사이즈 더블

        this.WaveGroup.resize(this.stageWidth,this.stageHeight);
    }

    animate(t) {
        this.ctx.clearRect(0, 0, this.stageWidth, this.stageHeight);
        window.requestAnimationFrame(this.animate.bind(this));

        this.WaveGroup.draw(this.ctx);
    }

}
window.onload = () => {
    new App();
}