<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=1200">
    <title>다이어리 작성 - LIFEINIT</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/diarywrite.css">
    <script src="./write.js"></script>
	
	
</head>

<body>
    <div id="wrap">
        <div id="header">
            <div class="header_inner">
                <h1 class="logo"><a href="index.php"><img src="./images/logo.png" alt="LIFEINIT"></a></h1>
                <ul class="gnb">
                    <li><a href="#">Today's Best</a></li>
                    <li><a href="#" style="color:#FF8800">내 다이어리</a></li>
                    <li><a href="#">SHOP</a></li>
                    <li><a href="#">SOCIAL</a></li>
                    <li><a href="#">GAME</a></li>
                </ul>
                <ul class="login_join">
                    <li><a href="#">로그인</a></li>
                    <li><a href="#">회원가입</a></li>
                </ul>
            </div>
        </div>
        <div id="container">
            <div class="diary_wrap">
                <div class="diary">
                    <div class="diary_header">
                        <h3><textarea class="title" rols="1" cols="20"> 현정 다이어리 </textarea></h3>
                        <div>
                            <ul class="write_btn">
							<form action="sqlimage.php" method="post" enctype="multipart/form-data">
							
							
						
			<div> 
				<input type="file" name="fileToUpload" id="fileToUpload">
			
			<input type="submit" value="업로드" name="submit" style="margin: .4em"></div>
							</form>							
                                <li><button type="button" onclick="addtext()">텍스트</button></li>
                                <li><button type="button" onclick="addimg()">이미지</button></li>	
                                <li><button type="button" onclick="addbgm()">음악</button></li>
                                <li><button type="button">스티커</button></li>
                            </ul>
                        </div>
						
                       <div class="bgm_wrap">
                            <audio style="display:none;" id="bgm" class="header_music" src="./mp3/Kirby.mp3"></audio>
                            <button style="margin-left: 10px;"onclick="document.getElementById('bgm').play()">▶</button>
                            <button style="margin-right: 10px;"onclick="document.getElementById('bgm').pause()">| |</button>
                            <h5 class="bgm_name">노래 제목</p>
                        </div>
                        
                        <button type="button" id="diary_submit" onclick="submit_form()"> 다이어리 수정 완료 </a>
                    </div>

                    <div class="content">
                        <div id="writearea" class="content_write">

                        </div>

                    </div>
                </div>
                <form id="submit_form" method="get" action = "write_action.php">
                    <div class="formwrap">
                        <h3 class="submit_head"> 다이어리 게시 </h3><br>
                        <div class="sub_element">
                            <label for="sub_title" class="smalltitle sub_category"> 제목 </label>
							
                            <input id="sub_title" placeholder="제목을 입력하세요" name="title" type="text"><br></div>
                        <div class="sub_element">
                            <label class="sub_category"> 공개 범위 </label>
                            <ul class="sub_scale">
                                <li><input type="radio" name="scale" value="all" checked="checked">전체 공개</li>
                                <li><input type="radio" name="scale" value="group">친구 공개</li>
                                <li><input type="radio" name="scale" value="private">비공개</li>
                            </ul><br>
                        </div>
                        <div class="sub_element">
                            <label class="sub_category"> 해시태그 </label>
                            <div class="hashtag_wrap">
                                <ul class="sub_hashtag">
                                    <li><input type="checkbox" name="scale">뷰티</li>
                                    <li><input type="checkbox" name="scale">그림</li>
                                    <li><input type="checkbox" name="scale">영화</li>
                                    <li><input type="checkbox" name="scale">음악</li>
                                    <li><input type="checkbox" name="scale">일상</li>
                                    <li><input type="checkbox" name="scale">음식</li>
                                    <li><input type="checkbox" name="scale">여행</li>
                                    <li><input type="checkbox" name="scale">운동</li>
                                </ul><br>
                            </div>
                        </div>
                        <div class="sub_element category_wrap">
                            <label class="sub_category"> 태그 </label>
                            <input class="sub_tag" name = "tag" type="text" placeholder="태그할 친구를 입력하세요">
                        </div><br>
                        <div class="sub_btnwrap">
							
                            <button type="submit" value = "게시"> 게시 </button>
							
                            <button type="button" class="sub_btn cancel_btn" onclick="cancel()"> 취소 </button>
                        </div>
                </form>
            </div>

            <div class="menu_wrap">
                <ul class="diary_menu">
                    <li><a href="#"> 홈 </a></li>
                    <li><a href="./profile.html"> 프로필 </a></li>
                    <li><a href="#"> 내가 태그된 </a></li>
                    <li><a href="#"> 공유</a></li>
                    <li><a href="gallery.php"> 사진첩 </a></li>
                </ul>
            </div>
        </div>
    </div>

    <div id="footer">
        <p> 2020년 2분기 AYC 소속 펫파시 팀 프로젝트 </p>
        <p> 강성문 남현정 이휘정 임서연 </p>
        <img src="./images/로고.png">
    </div>
    </div>
</body>

</html>