	<!-- database에서 이미지 목록을 가져 온다. -->
	<ul>
<?php

	$conn = mysqli_connect("localhost", "root", "1234", "test");
	if(mysqli_connect_errno()){
		echo "연결실패! ".mysqli_connect_error();
	}
	$query = "SELECT * FROM images";
	$result = mysqli_query($conn, $query);

	while($data = mysqli_fetch_array($result)){
		
		echo '<li style=\'float:left; margin: 2px;\'>';
		echo '<img src='.$data['imgurl'].' width=200><br>';
		echo ($data['filename']);
		echo '</li>';
	}

   mysqli_close($conn);
?>
		
	</ul>