function submit_form() {
  var form=document.getElementById("submit_form");
  form.style.display="block";
}
function cancel() {
  //폼 다시 안보이게 하기
  var form=document.getElementById("submit_form");
  form.style.display="none";
}

function addbgm(obj) {
  var audio=document.getElementsByClassName("bgm_wrap");
  audio[0].style.display="block";
  var bgm=document.getElementById("bgm");
  bgm.src="mp3/Kirby.mp3";
  var title=document.getElementsByClassName("bgm_name");
  title[0].innerText="Kirby"
}

function addimg() {
  var p = document.getElementById("writearea");
  var inputwrap=document.createElement("div");
  inputwrap.setAttribute("id","inputwrap");
  p.appendChild(inputwrap);
  inputwrap.style.position="absolute";
  
  var input = document.createElement("img");
  input.setAttribute("id", "addimg");
  input.src = name;

  input.draggable="true";
  input.addEventListener('dragend',function(Event){
    dragend_handler(Event,inputwrap);
  });
  input.addEventListener('mouseover',function(Event){
    editshow(editwrap);
  })
  input.display="block";
  inputwrap.appendChild(input);

  var editwrap=document.createElement("div");
  editwrap.setAttribute("id","editwrap");
  editwrap.display="none";
  editwrap.style.width="100%";
  editwrap.style.height="25px";
  inputwrap.appendChild(editwrap);

  var deletebtn = document.createElement("button");
  deletebtn.addEventListener('click',function(Event){
    deleteinput(inputwrap);
  })
  deletebtn.display="block";
  deletebtn.innerText="✖";
  deletebtn.style.backgroundColor="#FFF";
  deletebtn.style.color="black";
  deletebtn.style.fontWeight="bold";
  deletebtn.style.fontSize="16px";
  deletebtn.style.border="1px solid #EEE";
  deletebtn.style.width="20px";
  deletebtn.style.height="20px";
  deletebtn.addEventListener('mouseover',function(Event){
    deletebtn.style.color="#FF8800";
  })
  deletebtn.addEventListener('mouseleave',function(Event){
    deletebtn.style.color="black";
  })

  var bar=document.createElement("img");
  bar.src="./images/bar.png"
  bar.style.height="20px";
  bar.display="block";
  bar.style.paddingTop="3px";

  var width=document.createElement("input");
  width.type="text"
  width.style.fontFamily="맑은고딕";
  width.display="block";
  width.cols="4";
  width.rows="1";
  width.style.backgroundcolor="#FFF";
  width.style.border="1px solid #EEE";
  width.style.marginRight="5px";
  width.style.width="30px";
  width.value=input.width;

  var height=document.createElement("input");
  height.style.fontFamily="맑은고딕";
  height.display="block";
  height.cols="4";
  height.rows="1";
  height.style.backgroundcolor="#FFF";
  height.style.border="1px solid #EEE";
  height.style.marginRight="5px";
  height.style.width="30px";
  height.value=input.height;
  height.addEventListener('keypress',function(Event){
    if(Event.key=='Enter'){ //엔터 입력하면
      alert("확인");
      resizeimg(input,Number(width.value),Number(height.value));
    }
  })

  var resizebtn=document.createElement("button");
  resizebtn.display="block";
  resizebtn.innerText="크기변경";
  resizebtn.style.backgroundColor="#FFF";
  resizebtn.style.color="#444";
  resizebtn.style.fontSize="12px";
  resizebtn.style.border="1px solid #EEE";
  resizebtn.addEventListener('mouseover',function(Event){
    resizebtn.style.color="#FF8800";
  })
  resizebtn.addEventListener('mouseleave',function(Event){
    resizebtn.style.color="#444";
  })
  resizebtn.addEventListener('click',function(Event){
    // alert("사이즈 확인 ("+width.value+","+height.value+")");
    resizeimg(input,Number(width.value),Number(height.value));
  })

  inputwrap.addEventListener('mouseover',function(Event){
    editwrap.style.display="block";
  })

  inputwrap.addEventListener('mouseleave',function(Event){
    editwrap.style.display="none";
  })

  editwrap.appendChild(deletebtn);
  editwrap.appendChild(bar);
  editwrap.appendChild(width);
  editwrap.appendChild(height);
  editwrap.appendChild(resizebtn);


  input.focus();
  
  
}

function addtext(){
  var p = document.getElementById("writearea");
  var inputwrap=document.createElement("div");
  inputwrap.setAttribute("id","inputwrap");
  inputwrap.style.position="absolute";
  p.appendChild(inputwrap);
  
  var input = document.createElement("textarea");
  input.type="text";
  input.draggable="true";
  // input.value="내용을 입s력하세요";
  input.setAttribute("id", "addtext");
  input.display="block";

  var deletebtn = document.createElement("button");
  deletebtn.addEventListener('click',function(Event){
    deleteinput(inputwrap);
  })
  deletebtn.style.display="none";
  deletebtn.innerText="✖";
  deletebtn.setAttribute("id","btn");
  deletebtn.style.backgroundColor="#FFF";
  deletebtn.style.color="black";
  deletebtn.style.fontWeight="bold";
  deletebtn.style.fontSize="16px";
  deletebtn.style.border="1px solid #EEE";
  deletebtn.style.width="20px";
  deletebtn.style.height="20px";
  deletebtn.addEventListener('mouseover',function(Event){
    deletebtn.style.color="#FF8800";
  })
  deletebtn.addEventListener('mouseleave',function(Event){
    deletebtn.style.color="black";
  })


  input.addEventListener('dragend',function(Event){
    dragend_handler(Event,inputwrap);
    resize(inputwrap);
  });
  input.addEventListener('keyup',function(Event){
    resize(inputwrap);
  });
  input.addEventListener('keydown',function(Event){
    resize(inputwrap);
  });

  input.addEventListener('dragleave',function(Event){
    resize(this);
  })
  inputwrap.addEventListener('mouseover',function(Event){
    editshow(deletebtn);
  })
  inputwrap.addEventListener('mouseleave',function(Event){
    deletebtn.style.display="none";
  })
  inputwrap.appendChild(input);
  inputwrap.appendChild(deletebtn);

  input.focus();

  document.cookie="input";
}

// element 버튼 클릭 요소
function resizeimg(obj,val1,val2){
  obj.width=val1;
  obj.height=val2;
}
function deleteinput(obj){
  var p = document.getElementById("writearea");
  p.removeChild(obj);
}

function editshow(obj){
  //마우스를 갖다댔을 때, 버튼이 나타나게하기
  obj.style.display="block";
}
function resize(obj){
  //textarea 사이즈 재설정 함수
  obj.style.height='auto';
  obj.style.height = "1px";
  obj.style.height = (12+obj.scrollHeight)+"px";
  obj.style.width=obj.style.width;
}


// 드래그
function dragend_handler(ev,obj) {
  //drag가 끝난 후 위치를 이동시키는 함수
  ev.dataTransfer.dropEffect = "move";
  // const tem = document.querySelector("#p1").innerHTML;
  // alert("드래그 종료 (" + ev.screenX + "/" + ev.screenY+")");
  // alert("사이즈 ("+obj.style.width+","+obj.style.height+")");

  if(ev.screenX>=620&&ev.screenX<=1420&&ev.screenY>=370&&ev.screenY<=860){
  // const target = document.getElementById('p1');
  obj.style="position: absolute; margin-left:"+(ev.screenX-620)+"px; margin-top:"+(ev.screenY-370)+"px;"; 
  //상대 좌표로 넣어야해서 writearea(620,370) 빼주기)

  // const clientRect = target.getBoundingClientRect(); // DomRect 구하기 (각종 좌표값이 들어있는 객체)
  // const relativeTop = clientRect.top; // Viewport의 시작지점을 기준으로한 상대좌표 Y 값.
  }else if(ev.screenX>=620&&ev.screenX<=1420&&ev.screenY>=(860-obj.height)){ //y축 아래로 벗어남
    obj.style="position: absolute; margin-left:"+(ev.screenX-620)+"px; margin-top:"+(500-obj.height)+"px;"; 
  }else if(ev.screenX>=620&&ev.screenX<=1420&&ev.screenY<=370){ //y축 위로 벗어남
    obj.style="position: absolute; margin-left:"+(ev.screenX-620)+"px; margin-top:"+0+"px;"; 
  }else if(ev.screenY>=370&&ev.screenY<=860&&ev.screenX<=620){ //X축 왼쪽으로 벗어남
    obj.style="position: absolute; margin-left:"+0+"px; margin-top:"+(ev.screenY-370)+"px;"; 
  }else if(ev.screenY>=370&&ev.screenY<=860&&ev.screenX>=1420-obj.width){ //X축 오른쪽으로 벗어남
    obj.style="position: absolute; margin-left:"+(800-obj.width)+"px; margin-top:"+(ev.screenY-370)+"px;"; 
  }

}
