<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=1200">
    <title>LIFEINIT</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/common.css">
    <script src="./js/index.js"></script>
</head>

<body>
    <div id="wrap">
        <div id="header">
            <div class="header_inner">
                <h1 class="logo"><a href="../index.php"><img src="./images/logo.png" alt="LIFEINIT"></a></h1>
                <ul class="gnb">
                    <li><a href="./sy/best.php">Today's Best</a></li>
                    <li><a href="#" style="color:#FF8800">내 다이어리</a></li>
                    <li><a href="./sy/shop.php">SHOP</a></li>
                    <li><a href="./sy/search_first.php">SOCIAL</a></li>
                    <li><a href="./sy/game.php">GAME</a></li>
                </ul>
                <ul class="login_join">
                    <li><a href="#">로그인</a></li>
                    <li><a href="#">회원가입</a></li>
                </ul>
            </div>
        </div>
        <div id="container">
            <div class="diary_wrap">
                <div class="diary">
                    <div class="diary_header">
                        <h3> 현정 다이어리 </h3>
                        <a href="diarywrite.php"> 다이어리 추가 </a>
                    </div>
                    <div class="content">
                        <div class="content_list">

                        </div>
                        <div class="content_page">
                            <button class="content_btn content_prev" type="button"></button>
                            1/3
                            <button class="content_btn content_next" type="button"></button>
                        </div>
                    </div>
                </div>
                <div class="menu_wrap">
                    <ul class="diary_menu">
                        <li><a href="#"> 홈 </a></li>
                        <li><a href="#"> 프로필 </a></li>
                        <li><a href="#"> 내가 태그된 </a></li>
                        <li><a href="#"> 공유</a></li>
                        <li><a href="#"> 사진첩 </a></li>
                    </ul>
                </div>
            </div>
        </div>

        <div id="footer">
            <p> 2020년 2분기 AYC 소속 펫파시 팀 프로젝트 </p>
            <p> 강성문 남현정 이휘정 임서연 </p>
            <img src="./images/로고.png">
        </div>
    </div>
</body>

</html>