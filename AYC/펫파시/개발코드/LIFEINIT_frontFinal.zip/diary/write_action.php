<?php
                $connect = mysqli_connect("localhost", "root", "1234", "test") or die("fail");
                
                                     //Password
                $title = $_GET['title']; 
				$tag = $_GET['tag'];
				$text = $_COOKIE['input'];



							
							//Title
                          //Date
 
//return URL
				
				
 
                $query = "insert into testman (title,tag,text) 
                        values('$title','$tag', '$text')";
 
 
                $result = $connect->query($query);
				$URL = './index.php';
                if($result){
?>                  <script>
                        alert("<?php echo "글이 등록되었습니다."?>");
                        location.replace("<?php echo $URL?>");
                    </script>
<?php
                }
                else{
                        echo "FAIL";
                }
				
 
                mysqli_close($connect);
?>




	