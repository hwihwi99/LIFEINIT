<?php
$servername = "localhost";
$username = "root";
$password = "1234";
$dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// sql to create tables
//$sql = "create table board123 (
//     number int unsigned not null primary key auto_increment,
 //    title varchar(150) not null,
 //    content text not null,
 //    id varchar(20) not null,
 //    password varchar(20) not null,
 //    date datetime not null,
   //  hit int unsigned not null default 0
  //   )";


//if ($conn->query($sql) === TRUE) {
 //   echo "Table MyGuests created successfully";
//} else {
//    echo "Error creating table: " . $conn->error;
//}

$conn->close();
?>
<?php
                $connect = mysqli_connect("localhost", "root", "1234", "test") or die("fail");
                
                $id = $_GET[name];                      //Writer
                $pw = $_GET[pw];                        //Password
                $title = $_GET[title];                  //Title
                $content = $_GET[content];              //Content
                $date = date('Y-m-d H:i:s');            //Date
 
                $URL = './contents.php';                   //return URL
				
				
 
                $query = "insert into board123 (number,title, content, date, hit, id, password) 
                        values(null,'$title', '$content', '$date',0, '$id', '$pw')";
 
 
                $result = $connect->query($query);
                if($result){
?>                  <script>
                        alert("<?php echo "글이 등록되었습니다."?>");
                        location.replace("<?php echo $URL?>");
                    </script>
<?php
                }
                else{
                        echo "FAIL";
                }
 
                mysqli_close($connect);
?>




	