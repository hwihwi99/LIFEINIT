﻿<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=1200">
    <title>search_first</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/common.css">
    <script src="./js/index.js"></script>
    <style>
        input.form-text {
            border: none;
            text-align: center;
            outline: none;
            height: 25px;
            position: absolute;
            width: 920px;
            left: 5px;
        }

        input.img-button {
            background: url( "search.png" ) no-repeat;
            border: none;
            width: 32px;
            height: 32px;
            cursor: pointer;
            position: absolute;
            right: 5px;
        }

        .search {
            margin: auto;
            height: 35px;
            width: 960px;
            border: 1px solid #bcbcbc;
            border-radius: 10px;
            position: relative;
            margin-top: 50px;
        }

        .fb {
            position: relative;
            width: 100px;
            height: 40px;
            border: none;
            margin-left: 670px;
            margin-top: 430px;
        }

        .box{
                background: #ffdac1 0% 0% no-repeat padding-box;
border: 1px solid #7A7A7A;
border-radius: 25px;
opacity: 1;
width:288px;
height:80px;
            }
            #boxdiv{
                width:960px;
               margin:auto; 
               position:relative;
               top:50px;
            }
            .profile{
                height:70px;
                width:70px;
                object-fit: cover;
                 border-radius: 70%;
                 position:relative;
                 left:10px;
                 top:5px;
            }
            .name{
                position:relative;
                bottom:23px;
                left:10px;
                top:25px;
            }
    </style>
</head>

<body>
    <div id="wrap">
        <div id="header">
            <div class="header_inner">
                <h1 class="logo"><a href="../index.php"><img src="./images/logo.png" alt="LIFEINIT"></a></h1>
                <ul class="gnb">
                    <li><a href="best.php">Today's Best</a></li>
                    <li><a href="#" style="color:#FF8800">내 다이어리</a></li>
                    <li><a href="shop.php">SHOP</a></li>
                    <li><a href="search_first.php">SOCIAL</a></li>
                    <li><a href="game.php">GAME</a></li>
                </ul>
                <ul class="login_join">
                    <li><a href="#">로그인</a></li>
                    <li><a href="#">회원가입</a></li>
                </ul>
            </div>
        </div>
        <div id="container">
            <div class="search">
                <input type="text" class="form-text">
                <input type="button" class="img-button" onClick="location.href='search_second.html'">
            </div>
            <div id="boxdiv">
                <div class="box">
                    <img class="profile" src="my.png" />
                    <span class="name">임서연</span>
                </div>
            </div>
        </div>

    </div>
</body>

</html>