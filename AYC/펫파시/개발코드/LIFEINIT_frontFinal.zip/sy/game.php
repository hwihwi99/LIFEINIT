﻿<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=1200">
    <title>game</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/common.css">
    <script src="./js/index.js"></script>
    <style>
        #wrap #container .game_wrap{
            position: relative;
            margin:auto;
            margin-top : 50px;
            width:550px;
            height:600px;
        }
       #computer {
    width: 315px;
    height: 300px;
    position: relative;
            margin:auto;
    background: url('images/full.jpg') 0 0;
    margin-top : 25px;
}
       #user{
           margin-top:100px;
           display:none;
       }
       #rock{
           background: url( "images/1.jpg" ) no-repeat;
           width: 150px;
           height: 150px;
           float:left;
           border: none;       
           outline:none;
            
       }
       #scissor{
           background: url( "images/2.jpg" ) no-repeat;
           width: 150px;
            height: 150px;
            float:left;
            margin-left:50px;
            border: none;       
           outline:none;
       }
       #paper{
           background: url( "images/3.jpg" ) no-repeat;
           width: 150px;
            height: 150px;
            float:left;
            margin-left:50px;
            border: none;       
           outline:none;
       }
       #start{
           font-family: 'Ssurround','맑은 고딕';
            font-size: 28px;
            width:510px;
            margin:auto;
            position:relative;
            margin-top: 100px;
       }

       #coin, #coin2, #start_btn{
           font-family: 'Ssurround','맑은 고딕';
            font-size: 28px;
           
       }
       #start_btn{
           width:150px;
           height:50px;
           margin-left:50px;
           background: #FF8800 0% 0% no-repeat padding-box;
           color:#ffffff;
           border: 1px solid #FF8800;
            border-radius: 25px;
            outline:none;
       }
       #coin1{
           margin-left:60px;
           margin-top:60px;
       }
       #coin2{
           border: none;       
           outline:none;
       }
    </style>
</head>

<body>
    <div id="wrap">
        <div id="header">
            <div class="header_inner">
                <h1 class="logo"><a href="../index.php"><img src="./images/logo.png" alt="LIFEINIT"></a></h1>
                <ul class="gnb">
                    <li><a href="best.php">Today's Best</a></li>
                    <li><a href="#" style="color:#FF8800">내 다이어리</a></li>
                    <li><a href="shop.php">SHOP</a></li>
                    <li><a href="search_first.php">SOCIAL</a></li>
                    <li><a href="game.php">GAME</a></li>
                </ul>
                <ul class="login_join">
                    <li><a href="#">로그인</a></li>
                    <li><a href="#">회원가입</a></li>
                </ul>
            </div>
        </div>
        <div id="container">
            <div class="game_wrap">
                <div id="computer"></div>
                <div id="user">
                    <button id="rock" class="btn" onclick="game(this.id)"></button>
                    <button id="scissor" class="btn" onclick="game(this.id)"></button>
                    <button id="paper" class="btn" onclick="game(this.id)"></button>
                </div>
                <div id="start">
                    배팅금액 : <input type="text" id="coin" size="10">
                    <button id="start_btn" onclick="random()">시작하기</button>
                    보유코인 : <input type="text" id="coin2" size="16">
                </div>
                <script type="text/javascript">
                    window.onload = function () {;
                    document.getElementById("coin2").value = coin;
                    }
                    
                </script>
            </div>


            </div>
            <script>
                var bat = document.getElementById("start");
                var user = document.getElementById("user");
                var interval;
                var coin=10000;
                var nowcoin=0;
                var batcoin = parseInt(document.getElementById("coin").value);
                function random(){
                let imageCoordinate = '0';
                const dictionary = { // 딕셔너리 자료구조
                바위: '0',
                가위: '-317px',
                보: '-634px'
                };
                
                function intervalMaker() {
                interval = setInterval(function() {
                if (imageCoordinate == dictionary.바위) {
                imageCoordinate = dictionary.가위
                } else if (imageCoordinate == dictionary.가위) {
                imageCoordinate = dictionary.보;
                } else {
                imageCoordinate = dictionary.바위;
                }
                document.querySelector("#computer").style.background =
                'url(images/full.jpg) ' + imageCoordinate + ' 0';
                }, 100);
                }

                intervalMaker();

                bat.style.display='none';
                user.style.display='block';
                }

                function game(clicked_id){
                clearInterval(interval);
                var use;
                var com =  Math.floor( Math.random() * 3 )+1;
                if(clicked_id=='rock')
                    {use=1;} 
                if(clicked_id=='scissor')
                    {use=2;} 
                if(clicked_id=='paper')
                    {use=3;}

                if(com==1){
                    document.getElementById("computer").src = "./images/1.jpg";
                    switch(use){
                        case 1:
                            alert('무승부');
                            nowcoin=coin;
                            break;
                        case 2:
                            alert('패배');
                            coin.value=coin.value-batcoin;
                            nowcoin = eval(coin.value);
                            break;
                        case 3:
                            alert('승리');
                            coin.value=coin.value+batcoin;
                            nowcoin = eval(coin.value);
                            break;
                        }                   
                }
                else if(com==2){
                    document.getElementById("computer").src = "./images/2.jpg";
                    switch(use){
                        case 1:
                            alert('승리');
                            coin.value=coin.value+batcoin;
                            nowcoin = eval(coin.value);
                            break;
                        case 2:
                            alert('무승부');
                            nowcoin=coin;
                            break;
                        case 3:
                            alert('패배');
                            coin.value=coin.value-batcoin;
                            nowcoin = eval(coin.value);
                            break;
                        }
                }
                else if(com==3){
                    document.getElementById("computer").src = "./images/3.jpg";
                     switch(use){
                        case 1:
                            alert('패배');
                            coin.value=coin.value-batcoin;
                            nowcoin = eval(coin.value);
                            break;
                        case 2:
                            alert('승리');
                            coin.value=coin.value+batcoin;
                            nowcoin = eval(coin.value);
                            break;
                        case 3:
                            alert('무승부');
                            nowcoin=coin;
                            break;
                        }
                    
                }
                coin=nowcoin;
                bat.style.display='block';
                user.style.display='none';
                document.getElementById("coin2").value = coin;
                alert(com);
                alert(use);
                
                
                }
              
            </script>
            <div id="footer">
                <p> 2020년 2분기 AYC 소속 펫파시 팀 프로젝트 </p>
                <p> 강성문 남현정 이휘정 임서연 </p>
                <img src="./images/로고.png">
            </div>
        </div>
</body>

</html>