﻿<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=1200">
    <title>shop</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/common.css">
    <script src="./js/index.js"></script>
    <style>
 
        #wrap #container .shop_tab{
            position:relative;
            margin:auto;
            margin-top : 30px;
            width:480px;
            height:30px;
        }

        #wrap #container .shop_tab .shop li{
            float:left;
            list-style-type:none;
            margin-right : 150px;
        }
        #wrap #container .shop_tab .shop #no-margin{
            margin-right:0px;
        }
        #wrap #container .item_wrap{
            position: relative;
            margin:auto;
            margin-top : 10px;
            width:870px;
        }
        #wrap #container .item{
            width:150px;
            height:200px;
            position: relative;
            float:left;
            margin-left:20px;
            margin-top:30px;
        }
        #wrap #container .item .item_img{
            width:100px;
            height:100px;
            position: relative;
            margin:25px;
        }
        #wrap #container .item .item_name{
             text-align:center
        }
        #wrap #container .item .item_price{
             text-align:center
        }
    </style>
</head>

<body>
    <div id="wrap">
        <div id="header">
            <div class="header_inner">
                <h1 class="logo"><a href="#"><img src="./images/logo.png" alt="LIFEINIT"></a></h1>
                <ul class="gnb">
                    <li><a href="Best.html">Today's Best</a></li>
                    <li><a href="#" style="color:#FF8800">내 다이어리</a></li>
                    <li><a href="shop.html">SHOP</a></li>
                    <li><a href="search_first.html">SOCIAL</a></li>
                    <li><a href="game.html">GAME</a></li>
                </ul>
                <ul class="login_join">
                    <li><a href="#">로그인</a></li>
                    <li><a href="#">회원가입</a></li>
                </ul>
            </div>
        </div>
        <div id="container">
            <div class="shop_tab">
                <ul class="shop">
                    <li><a href="shop.html">다이어리테마</a></li>
                    <li><a href="shop2.html">스티커</a></li>
                    <li id="no-margin"><a href="shop3.html">글꼴</a></li>
                </ul>
            </div>
            <div class="item_wrap">
                <div class="item">
                    <img class="item_img" src="./images/12롯데마트드림Light.png"  onclick="buy()"/>
                    <div class="item_name">12롯데마트드림Light</div>
                    <div class="item_price">500코인</div>
                </div>
                <div class="item">
                    <img class="item_img" src="./images/210 도시락 B.png" onclick="buy()" />
                    <div class="item_name">210 도시락 Bt</div>
                    <div class="item_price">500코인</div>
                </div>
                <div class="item">
                    <img class="item_img" src="./images/HY목각파임B.png" onclick="buy()" />
                    <div class="item_name">HY목각파임B</div>
                    <div class="item_price">500코인</div>
                </div>
                <div class="item">
                    <img class="item_img" src="./images/MD개성체.png" onclick="buy()" />
                    <div class="item_name">MD개성체</div>
                    <div class="item_price">500코인</div>
                </div>
                <div class="item">
                    <img class="item_img" src="./images/배달의민족 한나체 Pro.png" onclick="buy()" />
                    <div class="item_name">배달의민족 한나체 Pro</div>
                    <div class="item_price">500코인</div>
                </div>
                <div class="item">
                    <img class="item_img" src="./images/상상토끼 신비는일곱살.png" onclick="buy()" />
                    <div class="item_name">상상토끼 신비는일곱살</div>
                    <div class="item_price">500코인</div>
                </div>
                <div class="item">
                    <img class="item_img" src="./images/휴먼둥근헤드라인.png" onclick="buy()" />
                    <div class="item_name">휴먼둥근헤드라인</div>
                    <div class="item_price">500코인</div>
                </div>
              
                
            </div>
        </div>

        <!--
       <div id="footer">
        <p> 2020년 2분기 AYC 소속 펫파시 팀 프로젝트 </p>
        <p> 강성문 남현정 이휘정 임서연 </p>
        <img src="./images/로고.png">
    </div>
    -->
        <script>
            function buy(){
            var jbResult = confirm( '구매하시겠습니까?' );
            if(jbResult==true){
            alert("구매하였습니다.")}
            }
        </script>
    </div>
</body>

</html>