﻿<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=1200">
    <title>best</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/common.css">
    <script src="./js/index.js"></script>
    <style>
        #wrap #container .best_wrap{
            position:relative;
           
        }
        #wrap #container .best_5_wrap {
            position: absolute;
            border: 1px solid #7A7A7A;
            border-radius: 25px;
            margin-left:-600px;
            left:50%;
            margin-top : 30px;
            width:1200px;
            height:250px;
        }
        #wrap #container .best_5_wrap h3 {
            color: #FF8800;
            font-family: 'Ssurround','맑은 고딕';
            font-size: 28px;
            margin-top:5px;
            position:absolute;
            margin-left:20px;
}
        #wrap #container .best_5_wrap .best_content{
            background: #ffdac1 0% 0% no-repeat padding-box;
            border: 1px solid #7A7A7A;
            width:200px;
            height:180px;
            position: relative;
            float:left;
            margin-left:30px;
            margin-top:50px;
            border-radius: 15px;
        }

        #wrap #container .best_5_wrap .best_content .user_wrap{
            width :180px;
            height:30px;
            position:relative;
            margin-left:10px;
            margin-top:5px;
            
        }
       
        #wrap #container .best_5_wrap .best_content .user_wrap .user_picture{
            height:30px;
                width:30px;
                object-fit: cover;
                 border-radius: 70%;
                 float:left;
        }

        #wrap #container .best_5_wrap .best_content .user_wrap .diary_name{
            height:30px;
            width:140px;
            margin-top:3px;
        }

        #wrap #container .best_5_wrap .best_content .diary_wrap{
            background: #ffffff 0% 0% no-repeat padding-box;
            width :180px;
            height:130px;
            position:relative;
            margin-left:10px;
            margin-top:5px;
        }

        #wrap #container .best_5_wrap .#best_1{
            
        }

        #wrap #container .best {
            position: absolute;         
            margin-left:-600px;
            left:50%;
            margin-top : 310px;
            width:1200px;
            height:1200px;
        }

        #wrap #container .best .best_content_all{
            background: #ffdac1 0% 0% no-repeat padding-box;
            border: 1px solid #7A7A7A;
            width:200px;
            height:180px;
            position: relative;
            float:left;
            margin-left:30px;
            margin-bottom:40px;
            border-radius: 15px;
        }
    </style>
</head>

<body>
    <div id="wrap">
        <div id="header">
            <div class="header_inner">
                <h1 class="logo"><a href="../index.php"><img src="./images/logo.png" alt="LIFEINIT"></a></h1>
                <ul class="gnb">
                    <li><a href="best.php"style="color:#FF8800">Today's Best</a></li>
                    <li><a href="../index.php" >내 다이어리</a></li>
                    <li><a href="shop.php">SHOP</a></li>
                    <li><a href="search_first.php">SOCIAL</a></li>
                    <li><a href="game.php">GAME</a></li>
                </ul>
                <ul class="login_join">
                    <li><a href="#">로그인</a></li>
                    <li><a href="#">회원가입</a></li>
                </ul>
            </div>
        </div>
        <div id="container">
            <div class="best_wrap">
                <div class="best_5_wrap">
                    <h3>BEST 5</h3>
                    <div class="best_content" id="best_1">
                        <div class="user_wrap">
                            <img class="user_picture" src="my.png" />
                            <div class="diary_name"> BEST 1</div>
                        </div>
                        <div class="diary_wrap">
						<center>
						
						
						<h1> 제목 :
						<?php
                $connect = mysqli_connect('localhost', 'root', '1234', 'test');
                
                $query = "select title from testboard1234";
                $result = $connect->query($query);
                $rows = mysqli_fetch_assoc($result);
				echo $rows['title'];
				
				mysqli_close($connect); 
        ?> </h1><a href = "../index.php"><img src = "../images/today_small.jpg" ></center></a>

                        </div>
                    </div>
                    <div class="best_content" id="best_2">

                    </div>
                    <div class="best_content" id="best_3">

                    </div>
                    <div class="best_content" id="best_4">

                    </div>
                    <div class="best_content" id="best_5">

                    </div>

                </div>
                <div class="best">
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                    <div class="best_content_all">

                    </div>
                </div>
            </div>
        </div>
        <!--
     <div id="footer">
        <p> 2020년 2분기 AYC 소속 펫파시 팀 프로젝트 </p>
        <p> 강성문 남현정 이휘정 임서연 </p>
        <img src="./images/로고.png">
    </div>
    -->

    </div>
</body>

</html>